const API_URL = "http://localhost:8080/api";

// Función integrada para obtener el token de seguridad
function getToken() {
    // Busca el token donde normalmente se guarda al hacer login. 
    // Nota: Si en tu login lo guardaste con otro nombre (ej. "jwt"), cambia la palabra "token" por ese nombre.
    return localStorage.getItem("token") || sessionStorage.getItem("token") || "";
}

// Aseguramos que el DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", () => {
    const consentimientoForm = document.getElementById("consentimientoForm");

    if (consentimientoForm) {
        const btnDibujar = document.getElementById("btnFirmaDibujar");
        const btnSubir = document.getElementById("btnFirmaSubir");
        const wrapperCanvas = document.getElementById("wrapperCanvas");
        const wrapperArchivo = document.getElementById("wrapperArchivo");
        let modoFirma = "dibujar";

        // Intercambio de pestañas funcional
        btnDibujar.addEventListener("click", () => {
            modoFirma = "dibujar";
            btnDibujar.classList.add("active"); 
            btnSubir.classList.remove("active");
            wrapperCanvas.style.display = "block"; 
            wrapperArchivo.style.display = "none";
        });

        btnSubir.addEventListener("click", () => {
            modoFirma = "subir";
            btnSubir.classList.add("active"); 
            btnDibujar.classList.remove("active");
            wrapperArchivo.style.display = "block"; 
            wrapperCanvas.style.display = "none";
        });

        // Inicialización y configuración del Canvas
        const canvas = document.getElementById("canvasFirma");
        const ctx = canvas.getContext("2d");
        let dibujando = false;
        ctx.strokeStyle = "#000000"; 
        ctx.lineWidth = 2;

        function getPos(e) {
            const rect = canvas.getBoundingClientRect();
            // Soporta tanto eventos de mouse como pantallas táctiles
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            return { x: clientX - rect.left, y: clientY - rect.top };
        }

        // Eventos de Mouse
        canvas.addEventListener("mousedown", (e) => { 
            dibujando = true; 
            const pos = getPos(e); 
            ctx.beginPath(); 
            ctx.moveTo(pos.x, pos.y); 
        });
        canvas.addEventListener("mousemove", (e) => { 
            if (dibujando) { 
                const pos = getPos(e); 
                ctx.lineTo(pos.x, pos.y); 
                ctx.stroke(); 
            } 
        });
        canvas.addEventListener("mouseup", () => dibujando = false);
        canvas.addEventListener("mouseleave", () => dibujando = false);

        // Soporte para Dispositivos Móviles (Touch events)
        canvas.addEventListener("touchstart", (e) => {
            e.preventDefault();
            dibujando = true;
            const pos = getPos(e);
            ctx.beginPath();
            ctx.moveTo(pos.x, pos.y);
        }, { passive: false });
        
        canvas.addEventListener("touchmove", (e) => {
            e.preventDefault();
            if (dibujando) {
                const pos = getPos(e);
                ctx.lineTo(pos.x, pos.y);
                ctx.stroke();
            }
        }, { passive: false });
        
        canvas.addEventListener("touchend", () => dibujando = false);

        // Botón Limpiar Trazo
        document.getElementById("btnClearCanvas").addEventListener("click", () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        });

        function canvasToFile(canvas, filename) {
            return new Promise((resolve) => {
                canvas.toBlob((blob) => {
                    resolve(new File([blob], filename, { type: "image/png" }));
                }, "image/png");
            });
        }

        // Envío del formulario hacia el Backend
        consentimientoForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const msgEl = document.getElementById("consentMsg");
            
            // 1. Validar que exista el token ANTES de intentar enviar
            const token = getToken();
            if (!token) {
                msgEl.style.color = "red";
                return msgEl.textContent = "Error: No estás autenticado. Por favor, inicia sesión de nuevo.";
            }

            msgEl.style.color = "#475569";
            msgEl.textContent = "Procesando registro...";

            const formData = new FormData();
            
            // ⚠️ OJO AQUÍ: Asegúrate de que donanteId.value sea un NÚMERO (ej: 5) y no texto (ej: "CC")
            formData.append("donanteId", document.getElementById("donanteId").value);
            formData.append("fechaFirma", document.getElementById("fechaFirma").value);

            // Agregar los campos requeridos por el DTO
            formData.append("firmaConsentimiento", "Firma registrada vía sistema"); 
            formData.append("tipoFirma", modoFirma === "subir" ? "FISICA" : "DIGITAL");

            if (modoFirma === "subir") {
                const fileInput = document.getElementById("archivoFirma");
                if (!fileInput.files || fileInput.files.length === 0) {
                    msgEl.style.color = "red";
                    return msgEl.textContent = "Por favor, sube un archivo de firma.";
                }
                formData.append("archivoFirma", fileInput.files[0]);
            } else {
                const archivoFirmaCanvas = await canvasToFile(canvas, "firma.png");
                formData.append("archivoFirma", archivoFirmaCanvas);
            }

            try {
                const url = `${API_URL}/consentimientos`;

                const response = await fetch(url, {
                    method: "POST",
                    headers: { 
                        "Authorization": `Bearer ${token}` 
                        // Nota: No se pone 'Content-Type' aquí porque fetch lo calcula automáticamente con FormData
                    },
                    body: formData
                });

                if (response.ok) {
                    msgEl.style.color = "green"; 
                    msgEl.textContent = "¡Donante y consentimiento registrados con éxito!";
                    consentimientoForm.reset(); 
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    setTimeout(() => { 
                        if(typeof closeModal === 'function') closeModal('donorModal'); 
                        msgEl.textContent = ""; 
                    }, 2000);
                } else {
                    const err = await response.json();
                    msgEl.style.color = "red"; 
                    msgEl.textContent = err.error || err.message || "Error al guardar en el servidor.";
                }
            } catch (error) {
                msgEl.style.color = "red";
                msgEl.textContent = "Error de conexión con el servidor remoto.";
                console.error("Detalle del error:", error);
            }
        });
    }
});