package co.sena.cimm.adso.Sistema_Donacion_Sangre.model;


import co.sena.cimm.adso.Sistema_Donacion_Sangre.enums.TipoFirma;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "consents")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Consentimiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "donante_id",nullable = false,unique = true)
    private Donante donante;

    @Column(name = "firma_consentimiento",nullable = false,columnDefinition = "TEXT")
    private  String firmaConsentimiento;

    @Column(name = "firma_digital", nullable = false, columnDefinition = "TEXT")
    private String firmaDigital;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_firma",nullable = false,length = 20)
    private TipoFirma tipoFirma;

    @Column(name = "fecha_firma", nullable = false)
    private LocalDateTime fechaFirma;

    @Column(name = "ip_firma", length =  50)
    private String ipFirma;


}
