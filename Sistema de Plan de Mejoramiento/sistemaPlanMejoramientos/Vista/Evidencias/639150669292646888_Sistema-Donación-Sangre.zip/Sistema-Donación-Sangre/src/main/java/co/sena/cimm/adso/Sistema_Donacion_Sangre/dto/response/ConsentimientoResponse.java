package co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.response;

import co.sena.cimm.adso.Sistema_Donacion_Sangre.enums.TipoFirma;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsentimientoResponse {
    private Long id;
    private Long donanteId;
    private String nombreDonante;
    private String firmaDigital;
    private TipoFirma tipoFirma;
    private LocalDateTime fechaFirma;
}
