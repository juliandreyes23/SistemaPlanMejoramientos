package co.sena.cimm.adso.Sistema_Donacion_Sangre.service.impl;

import co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.request.ConsentimientoRequest;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.response.ConsentimientoResponse;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.exception.BusinessException;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.exception.ResourceNotFoundException;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.mapper.ConsentimientoMapper;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.mapper.ConsentimientoMapper2;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.model.Consentimiento;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.model.Donante;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.repository.ConsentimientoRepository;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.repository.DonanteRepository;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.service.ConsentimientoService;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.service.FileStorageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;


@Slf4j
@Service
@RequiredArgsConstructor
public class ConsentimientoServiceImpl implements ConsentimientoService {

    private final DonanteRepository donanteRepository;
    private final ConsentimientoRepository consentimientoRepository;
    private final FileStorageService fileStorageService;
    private final ConsentimientoMapper consentimientoMapper;
    private final ConsentimientoMapper2  consentimientoMapper2;

    @Override
    public ConsentimientoResponse registrar(ConsentimientoRequest request) {
        log.info("Registrado consentimiento para donante id: {}", request.getDonanteId());

        Donante donante = buscarDonantePorId(request.getDonanteId());
        verificarConsentimientoNoDuplicado(request.getDonanteId());

        Consentimiento consentimiento = Consentimiento.builder()
                .donante(donante)
                .firmaConsentimiento(request.getFirmaConsentimiento())
                .tipoFirma(request.getTipoFirma())
                .fechaFirma(LocalDateTime.now())
                .build();

        donante.setAceptaConsentimiento(true);
        donanteRepository.save(donante);

        Consentimiento guardado = consentimientoRepository.save(consentimiento);
        log.info("Consentimiento registrado exitosamente con id {}", guardado.getId());

        return  consentimientoMapper.toResponse(guardado);
    }


    @Override
    @Transactional(readOnly = true)
    public ConsentimientoResponse buscarPorDonante(Long donanteId) {
        Consentimiento consentimiento = consentimientoRepository.findByDonanteId(donanteId) // ← este
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Consentimiento no encontrado para el donante con id: " + donanteId));
        return consentimientoMapper.toResponse(consentimiento);
    }

    @Override
    public boolean tieneConsentimientoFirmado(Long donanteId) {
        return consentimientoRepository.existsByDonanteId(donanteId);
    }




    private Donante buscarDonantePorId(Long id) {
        return donanteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Donante no encontrado con id: " + id));
    }

    private void verificarConsentimientoNoDuplicado(Long donanteId) {
        if (consentimientoRepository.existsByDonanteId(donanteId)) {
            throw new BusinessException(
                    "El donante con id " + donanteId + " ya tiene un consentimiento registrado");
        }
}
    @Override
    @Transactional
    public ConsentimientoResponse registrarConsentimiento(ConsentimientoRequest request) {
        Donante donante = donanteRepository.findById(request.getDonanteId())
                .orElseThrow(() -> new co.sena.cimm.adso.Sistema_Donacion_Sangre.exception.ResourceNotFoundException("Donante no encontrado con ID: " + request.getDonanteId()));

        String rutaFirma = fileStorageService.guardarFirma(request.getArchivoFirma());

        Consentimiento consentimiento = consentimientoMapper2.toEntity(request);
        consentimiento.setDonante(donante);

        consentimiento.setFirmaDigital(rutaFirma);

        return consentimientoMapper.toResponse(consentimientoRepository.save(consentimiento));
    }
}
