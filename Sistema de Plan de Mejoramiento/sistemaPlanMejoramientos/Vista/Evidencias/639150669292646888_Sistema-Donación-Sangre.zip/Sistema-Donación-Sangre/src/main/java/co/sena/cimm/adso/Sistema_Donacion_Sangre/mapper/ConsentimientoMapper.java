package co.sena.cimm.adso.Sistema_Donacion_Sangre.mapper;

import co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.request.ConsentimientoRequest;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.response.ConsentimientoResponse;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.model.Consentimiento;
import org.springframework.stereotype.Component;

@Component
public class ConsentimientoMapper {
    public ConsentimientoResponse toResponse(Consentimiento consentimiento) {
        return ConsentimientoResponse.builder()
                .id(consentimiento.getId())
                .donanteId(consentimiento.getDonante().getId())
                .nombreDonante(consentimiento.getDonante().getNombres() + " "
                        + consentimiento.getDonante().getApellidos())
                .tipoFirma(consentimiento.getTipoFirma())
                .fechaFirma(consentimiento.getFechaFirma())
                .build();
    }

}
