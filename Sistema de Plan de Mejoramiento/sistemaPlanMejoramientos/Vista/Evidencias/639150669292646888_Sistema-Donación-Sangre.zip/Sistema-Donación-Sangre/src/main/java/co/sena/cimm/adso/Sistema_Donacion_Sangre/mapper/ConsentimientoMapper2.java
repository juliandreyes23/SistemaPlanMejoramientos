package co.sena.cimm.adso.Sistema_Donacion_Sangre.mapper;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.request.ConsentimientoRequest;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.response.ConsentimientoResponse;
import co.sena.cimm.adso.Sistema_Donacion_Sangre.model.Consentimiento;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface ConsentimientoMapper2 {
    @Mapping(target = "donante", ignore = true)
    Consentimiento toEntity(ConsentimientoRequest request);

    @Mapping(target = "donanteId", source = "donante.id")
    ConsentimientoResponse toResponse(Consentimiento consentimiento);
}
