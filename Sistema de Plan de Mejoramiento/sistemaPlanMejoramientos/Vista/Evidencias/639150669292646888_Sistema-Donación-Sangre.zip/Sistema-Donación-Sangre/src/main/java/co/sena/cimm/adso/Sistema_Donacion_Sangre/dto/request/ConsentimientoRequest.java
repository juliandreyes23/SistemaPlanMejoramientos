package co.sena.cimm.adso.Sistema_Donacion_Sangre.dto.request;

import co.sena.cimm.adso.Sistema_Donacion_Sangre.enums.TipoFirma;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import lombok.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.format.annotation.DateTimeFormat; // 1. AGREGA ESTA IMPORTACIÓN

import java.time.LocalDate;

@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConsentimientoRequest {

    @NotNull(message = "El donante es obligatorio")
    private Long donanteId;

    @NotBlank(message = "La firma es obligatoria")
    private String firmaConsentimiento;

    @NotNull(message = "El tipo de firma es obligatorio")
    private TipoFirma tipoFirma;

    @NotNull(message = "El archivo de la firma es obligatorio")
    private MultipartFile archivoFirma;

    @NotNull(message = "La fecha de la firma es obligatoria")
    @PastOrPresent(message = "La fecha de firma no puede ser futura")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // 2. AGREGA ESTA LÍNEA JUSTO AQUÍ
    private LocalDate fechaFirma;
}